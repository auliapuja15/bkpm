<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login - Sistem Informasi Akademik</title>

    <!-- Bootstrap-->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container">

        <div class="row justify-content-center mt-5">

            <div class="col-md-5">

                <div class="card shadow-sm">

                    <div class="card-body p-4">

                        <h2 class="text-center mb-4">
                            Sistem Informasi Akademik
                        </h2>

                        
                        <h4 class="text-center mb-3">
                            Login
                        </h4>

                        <p class="text-center text-muted mb-4">
                            Selamat datang di halaman login mahasiswa dan dosen.
                        </p>

                        <form action="<?= BASE_URL ?>/login/process" method="POST">

                            <div class="mb-3">
                                <label class="form-label">
                                    Username
                                </label>

                                <input
                                    type="text"
                                    name="username"
                                    class="form-control"
                                    required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">
                                    Password
                                </label>

                                <input
                                    type="password"
                                    name="password"
                                    class="form-control"
                                    required>
                            </div>

                            <button
                                type="submit"
                                class="btn btn-primary w-100">
                                Login
                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

</body>

</html>